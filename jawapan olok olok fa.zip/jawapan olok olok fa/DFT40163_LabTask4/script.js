
const displaySummary = (isApproved, data, reasons = []) => {
    // 1. Clear previous content
    const container = document.getElementById('summaryContainer');
    $(container).empty(); 

    // Determine the result status and class
    const statusClass = isApproved ? 'accepted' : 'rejected';

    // 2. Create and append the main result header
    const header = document.createElement('p');
    header.className = statusClass;
    header.classList.add('result-header'); 

    if (isApproved) {
        $(header).text('Application Approved! Welcome to the Adventure Camp.');
    } else {
        $(header).text('Application Rejected. You can try again later!');
    }
    container.appendChild(header);

   
    if (!isApproved) {
        reasons.forEach(reason => {
            const reasonLine = document.createElement('p');
            reasonLine.className = 'result-line rejected';
            $(reasonLine).text(`- ${reason}`);
            container.appendChild(reasonLine);
        });
    }

   
    if (isApproved) {
        const details = [
            `Name: ${data.name}`,
            `Age: ${data.age}`,
            `Weight: ${data.weight} kg`,
            `Height: ${data.height} cm`,
            `Chronic Disease: ${data.chronic === "no" ? "No" : "Yes"}`
        ];

        details.forEach(detail => {
            const detailLine = document.createElement('p');
            detailLine.className = 'result-line';
            $(detailLine).text(detail);
            container.appendChild(detailLine);
        });
    }
}


$(document).ready(function () {
    $('#applicationForm').submit(function (event) {
        event.preventDefault();

        // 1. Collect Data (Q1)
        const name = $('#name').val().trim();
        const age = parseInt($('#age').val());
        const weight = parseFloat($('#weight').val());
        const height = parseFloat($('#height').val());
        const chronic = $('#chronic').val();
        
        const userData = { name, age, weight, height, chronic };

        let errors = [];

        // 2. Check for empty fields (Q2)
        if (!name) errors.push("Please enter your full name.");
        if (!age) errors.push("Please enter your age.");
        if (!weight) errors.push("Please enter your weight.");
        if (!height) errors.push("Please enter your height.");
        if (!chronic) errors.push("Please select your chronic disease status.");

        // Show popups for each missing field and stop if errors exist
        if (errors.length > 0) {
            errors.forEach(err => alert(err));
            return;
        }
        
        // 3. Confirmation Popup (Q2)
        const confirmApply = confirm("All details are valid. Do you want to submit the application?");
        if (!confirmApply) {
            alert("Application not submitted.");
            return;
        }

        // 4. Calculate BMI and Check Eligibility (Q4)
        const bmi = weight / Math.pow(height / 100, 2);
        let rejectionReasons = [];
        let isApproved = true;

        if (age < 18 || age > 45) {
            rejectionReasons.push("Your age is not within the condition of 18-45.");
            isApproved = false;
        }
        if (bmi < 18 || bmi > 25) {
            rejectionReasons.push(`Your height and weight don't meet the BMI condition (18-25). Your BMI is ${bmi.toFixed(2)}.`);
            isApproved = false;
        }
        if (chronic === "yes") {
            rejectionReasons.push("Chronic disease disqualifies the application due to safety reasons.");
            isApproved = false;
        }

        // 5. Display Results (Q3 & Q4)
        if (isApproved) {
            displaySummary(true, userData);
        } else {
            displaySummary(false, userData, rejectionReasons);
        }
        
        // Hide form and show result interface (Q3)
        $('#formSection').hide();
        $('#resultSection').show();
    });
});